# CIO

This package implements Contact Invariant Optimization by Mordatch, et al.

To see if you meet the dependencies run:
```
python3 test.py
```

To follow a tutorial on how to use the package, launch a jupyter notebook with the following command
```
jupyter notebook
```
and open CIO_notebook.ipynb
